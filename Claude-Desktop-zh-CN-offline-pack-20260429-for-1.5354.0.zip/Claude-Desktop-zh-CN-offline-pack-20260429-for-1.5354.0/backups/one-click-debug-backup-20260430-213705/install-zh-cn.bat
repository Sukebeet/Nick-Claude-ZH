@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "INSTALL_PS1=%SCRIPT_DIR%scripts\install-claude-zh-cn.ps1"

if not exist "%INSTALL_PS1%" (
  echo [ERROR] Missing installer script:
  echo %INSTALL_PS1%
  pause
  exit /b 1
)

set "PSHOST="
if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PSHOST=%ProgramFiles%\PowerShell\7\pwsh.exe"
if not defined PSHOST if exist "%LocalAppData%\Microsoft\WindowsApps\pwsh.exe" set "PSHOST=%LocalAppData%\Microsoft\WindowsApps\pwsh.exe"
if not defined PSHOST set "PSHOST=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

if not exist "%PSHOST%" (
  echo [ERROR] PowerShell was not found:
  echo %PSHOST%
  pause
  exit /b 1
)

echo Claude zh-CN installer
echo Package folder:
echo %SCRIPT_DIR%
echo.
echo Launching installer with administrator privilege...
set "CLAUDE_ZH_INSTALL_PS1=%INSTALL_PS1%"
set "CLAUDE_ZH_PS_HOST=%PSHOST%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$script=$env:CLAUDE_ZH_INSTALL_PS1; $hostExe=$env:CLAUDE_ZH_PS_HOST; $p=Start-Process -FilePath $hostExe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$script); exit $p.ExitCode"

echo.
echo Installer window has finished.
echo If Claude did not open automatically, start Claude Desktop once manually.
pause
