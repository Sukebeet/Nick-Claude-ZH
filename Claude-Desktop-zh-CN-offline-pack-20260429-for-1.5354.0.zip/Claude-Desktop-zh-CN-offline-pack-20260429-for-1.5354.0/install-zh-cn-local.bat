@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "MAIN_INSTALLER=%SCRIPT_DIR%install-zh-cn.bat"

if not exist "%MAIN_INSTALLER%" (
  echo [ERROR] Missing installer:
  echo %MAIN_INSTALLER%
  pause
  exit /b 1
)

call "%MAIN_INSTALLER%"
exit /b %ERRORLEVEL%
