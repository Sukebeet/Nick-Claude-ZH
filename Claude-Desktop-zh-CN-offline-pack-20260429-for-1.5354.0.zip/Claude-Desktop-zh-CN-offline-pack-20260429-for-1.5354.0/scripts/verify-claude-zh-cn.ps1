﻿param(
    [string]$ClaudeAppRoot = '',
    [switch]$AppOnly
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

function Find-ClaudeAppRoot {
    param([string]$ExplicitRoot)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRoot)) {
        if (-not (Test-Path -LiteralPath $ExplicitRoot -PathType Container)) {
            throw "ClaudeAppRoot does not exist: $ExplicitRoot"
        }
        return (Resolve-Path -LiteralPath $ExplicitRoot).Path
    }

    $windowsApps = Join-Path $env:ProgramFiles 'WindowsApps'
    $candidates = Get-ChildItem -LiteralPath $windowsApps -Directory -Filter 'Claude_*__pzs8sxrjxfjjc' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $app = Join-Path $_.FullName 'app'
            $exe = Join-Path $app 'Claude.exe'
            if (Test-Path -LiteralPath $exe -PathType Leaf) {
                [pscustomobject]@{
                    AppRoot = $app
                    LastWriteTime = $_.LastWriteTime
                }
            }
        }

    if (-not $candidates -or $candidates.Count -eq 0) {
        throw "Could not find Claude Desktop. Pass -ClaudeAppRoot manually."
    }

    return ($candidates | Sort-Object LastWriteTime -Descending | Select-Object -First 1).AppRoot
}

function Test-FileContains {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Text
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $false
    }

    return [IO.File]::ReadAllText($Path).Contains($Text)
}

$installRoot = Find-ClaudeAppRoot -ExplicitRoot $ClaudeAppRoot
$resources = Join-Path $installRoot 'resources'
$assetRoot = Join-Path $resources 'ion-dist\assets\v1'

$checks = New-Object System.Collections.Generic.List[object]
function Add-Check([string]$Name, [bool]$Passed, [string]$Detail) {
    $checks.Add([pscustomobject]@{
        Check = $Name
        Passed = $Passed
        Detail = $Detail
    })
}

$desktopZh = Join-Path $resources 'zh-CN.json'
$ionZh = Join-Path $resources 'ion-dist\i18n\zh-CN.json'
$statsigZh = Join-Path $resources 'ion-dist\i18n\statsig\zh-CN.json'

Add-Check 'desktop zh-CN.json exists' (Test-Path -LiteralPath $desktopZh -PathType Leaf) $desktopZh
Add-Check 'ion-dist zh-CN.json exists' (Test-Path -LiteralPath $ionZh -PathType Leaf) $ionZh
Add-Check 'statsig zh-CN.json exists' (Test-Path -LiteralPath $statsigZh -PathType Leaf) $statsigZh

$jsText = ''
if (Test-Path -LiteralPath $assetRoot -PathType Container) {
    foreach ($file in Get-ChildItem -LiteralPath $assetRoot -Filter '*.js' -File) {
        $jsText += [IO.File]::ReadAllText($file.FullName)
        $jsText += "`n"
    }
}

Add-Check 'language whitelist contains zh-CN' ($jsText.Contains('"zh-CN"') -or $jsText.Contains('k="zh-CN"')) 'JS assets'
Add-Check 'sidebar hardcoded labels patched' ($jsText.Contains('label:"协作"') -and $jsText.Contains('label:"项目"') -and $jsText.Contains('label:"计划任务"')) 'JS assets'
Add-Check 'projects page patched' (($jsText.Contains('title:"项目"') -or $jsText.Contains('defaultMessage:"项目"')) -and ($jsText.Contains('const He="新建项目"') -or $jsText.Contains('const Je="新建项目"') -or $jsText.Contains('defaultMessage:"新建项目"')) -and ($jsText.Contains('alphabetical:"按字母排序"') -or $jsText.Contains('创建时间') -or $jsText.Contains('你的项目'))) 'JS assets'
Add-Check 'scheduled tasks page patched' ($jsText.Contains('计划任务仅在电脑保持唤醒时运行') -and $jsText.Contains('还没有计划任务')) 'JS assets'
Add-Check 'skills menu mapping patched' ($jsText.Contains('"context":"上下文"') -and $jsText.Contains('"schedule":"定时任务"') -and $jsText.Contains('"setup-cowork":"设置协作"') -and $jsText.Contains('"consolidate-memory":"整理记忆"') -and $jsText.Contains('查看和管理当前会话上下文。') -and $jsText.Contains('引导完成协作模式设置：安装匹配插件、试用技能、连接工具。') -and $jsText.Contains('对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。')) 'JS assets'
Add-Check 'customize title patched' ($jsText.Contains('name:"自定义"')) 'JS assets'
Add-Check 'hardcoded sign out patched' ($jsText.Contains('退出登录')) 'JS assets'

if (-not $AppOnly) {
$configLocales = @()
if ($env:APPDATA -and (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
    $configLocales = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $configPath = Join-Path $_.FullName 'config.json'
            if (Test-Path -LiteralPath $configPath -PathType Leaf) {
                try {
                    $config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
                    [pscustomobject]@{ Path = $configPath; Locale = $config.locale }
                }
                catch {
                    [pscustomobject]@{ Path = $configPath; Locale = 'PARSE_FAILED' }
                }
            }
        }
}

$localeOk = $false
foreach ($item in $configLocales) {
    if ($item.Locale -eq 'zh-CN') {
        $localeOk = $true
    }
}
Add-Check 'at least one Claude config locale is zh-CN' $localeOk (($configLocales | ForEach-Object { "$($_.Path)=$($_.Locale)" }) -join '; ')

$skillsManifestOk = $false
$skillsManifestDetails = @()
if ($env:APPDATA -and (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
    $skillManifests = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $skillsRoot = Join-Path $_.FullName 'local-agent-mode-sessions\skills-plugin'
            if (Test-Path -LiteralPath $skillsRoot -PathType Container) {
                Get-ChildItem -LiteralPath $skillsRoot -Recurse -File -Filter 'manifest.json' -ErrorAction SilentlyContinue
            }
        }

    foreach ($manifest in $skillManifests) {
        try {
            $obj = Get-Content -LiteralPath $manifest.FullName -Raw | ConvertFrom-Json
            if (-not $obj.skills) {
                continue
            }
            $nameMap = @{}
            foreach ($skill in $obj.skills) {
                $nameMap[$skill.skillId] = $skill.name
            }
            $detail = "$($manifest.FullName): schedule=$($nameMap['schedule']); setup-cowork=$($nameMap['setup-cowork']); consolidate-memory=$($nameMap['consolidate-memory'])"
            $skillsManifestDetails += $detail
            if ($nameMap['schedule'] -eq '定时任务' -and $nameMap['setup-cowork'] -eq '设置协作' -and $nameMap['consolidate-memory'] -eq '整理记忆') {
                $skillsManifestOk = $true
            }
        }
        catch {
            $skillsManifestDetails += "$($manifest.FullName): PARSE_FAILED"
        }
    }
}
Add-Check 'at least one skills manifest is localized' $skillsManifestOk ($skillsManifestDetails -join '; ')

$skillMarkdownOk = $false
$skillMarkdownDetails = @()
if ($env:APPDATA -and (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
    $skillMarkdowns = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $skillsRoot = Join-Path $_.FullName 'local-agent-mode-sessions\skills-plugin'
            if (Test-Path -LiteralPath $skillsRoot -PathType Container) {
                Get-ChildItem -LiteralPath $skillsRoot -Recurse -File -Filter 'SKILL.md' -ErrorAction SilentlyContinue
            }
        }

    foreach ($skillFile in $skillMarkdowns) {
        try {
            $content = [IO.File]::ReadAllText($skillFile.FullName)
            if ($content.Contains('创建一个可按需运行或按固定间隔自动运行的定时任务。') -or $content.Contains('引导完成协作模式设置：安装匹配插件、试用技能、连接工具。') -or $content.Contains('对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。')) {
                $skillMarkdownOk = $true
            }
            $skillMarkdownDetails += $skillFile.FullName
        }
        catch {
            $skillMarkdownDetails += "$($skillFile.FullName): PARSE_FAILED"
        }
    }
}
Add-Check 'at least one skill markdown is localized' $skillMarkdownOk ($skillMarkdownDetails -join '; ')
}
else {
    Add-Check 'profile checks skipped' $true 'AppOnly'
}

Write-Host "Claude app root: $installRoot"
$checks | Format-Table -AutoSize

if (@($checks | Where-Object { -not $_.Passed }).Count -gt 0) {
    exit 1
}
