param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$ThisScriptPath = $PSCommandPath
if ([string]::IsNullOrWhiteSpace($ThisScriptPath)) {
    $ThisScriptPath = $env:CLAUDE_ZH_CN_INSTALLER_PATH
}
if ([string]::IsNullOrWhiteSpace($ThisScriptPath)) {
    throw 'Installer script path is unavailable.'
}

$PackageRoot = Split-Path -Parent (Split-Path -Parent $ThisScriptPath)
$PayloadRoot = Join-Path $PackageRoot 'payload\merged'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$ChangedFiles = New-Object System.Collections.Generic.List[string]

function Write-Step {
    param([Parameter(Mandatory = $true)][string]$Message)
    Write-Host "[Claude zh-CN local installer] $Message" -ForegroundColor Cyan
}

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Administrator privilege is required.'
    }
}

function Find-ClaudeAppRoot {
    $pkg = Get-AppxPackage Claude -ErrorAction Stop
    if (-not $pkg -or -not $pkg.InstallLocation) {
        throw 'Claude Desktop is not installed.'
    }

    $appRoot = Join-Path $pkg.InstallLocation 'app'
    $exe = Join-Path $appRoot 'Claude.exe'
    $resources = Join-Path $appRoot 'resources'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw "Claude.exe not found: $exe"
    }
    if (-not (Test-Path -LiteralPath $resources -PathType Container)) {
        throw "resources directory not found: $resources"
    }
    return $appRoot
}

function Grant-WriteAccess {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $currentGrant = ('*' + $currentSid + ':(F)')

    & takeown.exe /F $Path /A | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "takeown failed for $Path"
    }

    & icacls.exe $Path /grant:r '*S-1-5-32-544:(F)' | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "icacls administrators grant failed for $Path"
    }

    & icacls.exe $Path /grant:r $currentGrant | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "icacls current user grant failed for $Path"
    }
}

function Stop-Claude {
    $processes = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'Claude*' }
    foreach ($process in $processes) {
        Write-Step "Stopping $($process.ProcessName) ($($process.Id))"
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
    }
}

function Get-ClaudeProfileRoots {
    $roots = New-Object System.Collections.Generic.List[string]

    if ($env:LOCALAPPDATA -and (Test-Path -LiteralPath $env:LOCALAPPDATA -PathType Container)) {
        foreach ($dir in (Get-ChildItem -LiteralPath $env:LOCALAPPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue)) {
            $roots.Add($dir.FullName)
        }
    }

    if ($env:APPDATA -and (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
        foreach ($dir in (Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue)) {
            if (-not $roots.Contains($dir.FullName)) {
                $roots.Add($dir.FullName)
            }
        }
    }

    return $roots
}

function Clear-CodeCaches {
    $roots = Get-ClaudeProfileRoots
    foreach ($root in $roots) {
        $cacheDir = Join-Path $root 'Code Cache'
        if (Test-Path -LiteralPath $cacheDir -PathType Container) {
            Write-Step "Removing stale code cache: $cacheDir"
            Remove-Item -LiteralPath $cacheDir -Recurse -Force
        }
    }
}

function Copy-LanguageFiles {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    $resources = Join-Path $InstallRoot 'resources'
    $copyMap = @(
        [pscustomobject]@{
            Source = Join-Path $PayloadRoot 'desktop-shell.zh-CN.json'
            Destination = Join-Path $resources 'zh-CN.json'
        },
        [pscustomobject]@{
            Source = Join-Path $PayloadRoot 'ion-dist.zh-CN.json'
            Destination = Join-Path $resources 'ion-dist\i18n\zh-CN.json'
        },
        [pscustomobject]@{
            Source = Join-Path $PayloadRoot 'statsig.zh-CN.json'
            Destination = Join-Path $resources 'ion-dist\i18n\statsig\zh-CN.json'
        }
    )

    foreach ($item in $copyMap) {
        if (-not (Test-Path -LiteralPath $item.Source -PathType Leaf)) {
            throw "Missing payload file: $($item.Source)"
        }

        $destinationDir = Split-Path -Parent $item.Destination
        Grant-WriteAccess -Path $destinationDir
        if (Test-Path -LiteralPath $item.Destination) {
            Grant-WriteAccess -Path $item.Destination
        }

        Write-Step "Copying $($item.Source) -> $($item.Destination)"
        Copy-Item -LiteralPath $item.Source -Destination $item.Destination -Force
        $ChangedFiles.Add($item.Destination)
    }
}

function New-Patches {
    $patches = New-Object System.Collections.Generic.List[object]
    function Add-Patch([string]$Find, [string]$Replace) {
        $patches.Add([pscustomobject]@{ Find = $Find; Replace = $Replace })
    }

    Add-Patch 'HP=["en-US","de-DE","fr-FR","ko-KR","ja-JP","es-419","es-ES","it-IT","hi-IN","pt-BR","id-ID"]' 'HP=["en-US","zh-CN","de-DE","fr-FR","ko-KR","ja-JP","es-419","es-ES","it-IT","hi-IN","pt-BR","id-ID"]'
    Add-Patch '$z=["en-US","de-DE","fr-FR","ko-KR","ja-JP","es-419","es-ES","it-IT","hi-IN","pt-BR","id-ID"]' '$z=["en-US","zh-CN","de-DE","fr-FR","ko-KR","ja-JP","es-419","es-ES","it-IT","hi-IN","pt-BR","id-ID"]'

    Add-Patch 'label:"Chat"' 'label:"聊天"'
    Add-Patch 'label:"Cowork"' 'label:"协作"'
    Add-Patch 'label:"Code"' 'label:"代码"'
    Add-Patch 'label:"Customize"' 'label:"自定义"'
    Add-Patch 'label:"Projects"' 'label:"项目"'
    Add-Patch 'label:"Scheduled"' 'label:"计划任务"'
    Add-Patch 'label:"Live artifacts"' 'label:"实时制品"'
    Add-Patch 'label:"Dispatch"' 'label:"调度"'
    Add-Patch 'ariaLabel:"Code"' 'ariaLabel:"代码"'
    Add-Patch 'ariaLabel:"Cowork"' 'ariaLabel:"协作"'

    Add-Patch 'const hi="Recents"' 'const hi="最近"'
    Add-Patch 'chat:"New chat"' 'chat:"新聊天"'
    Add-Patch 'cowork:"New task"' 'cowork:"新任务"'
    Add-Patch 'code:"New session"' 'code:"新建会话"'
    Add-Patch 'operon:"New session"' 'operon:"新建会话"'
    Add-Patch 'children:["View all"' 'children:["查看全部"'
    Add-Patch 'children:"Pinned"' 'children:"已固定"'
    Add-Patch '"Let go"' '"松开"'
    Add-Patch '"Drop here"' '"拖到这里"'
    Add-Patch '"Drag to pin"' '"拖动固定"'
    Add-Patch 'mi="Untitled"' 'mi="未命名"'
 Add-Patch '"Recents"' '"最近"'
 Add-Patch '"Untitled"' '"未命名"'
 Add-Patch '||"Untitled"' '||"未命名"'
 Add-Patch 'defaultMessage:"Untitled"' 'defaultMessage:"未命名"'
 Add-Patch ':"Recent"' ':"最近"'
 Add-Patch 'recent:"Recent"' 'recent:"最近"'
 Add-Patch 'defaultMessage:"Recent"' 'defaultMessage:"最近"'
 Add-Patch 'defaultMessage:"Recents"' 'defaultMessage:"最近"'

    Add-Patch 'children:e.jsx(s,{defaultMessage:"Recents"' 'children:e.jsx(s,{defaultMessage:"最近"'
 Add-Patch 'mdTitle:e.jsx(s,{defaultMessage:"Recents"' 'mdTitle:e.jsx(s,{defaultMessage:"最近"'
 Add-Patch 'title:"Recents"' 'title:"最近"'
 Add-Patch 'defaultMessage:"Code"' 'defaultMessage:"代码"'
    Add-Patch 'defaultMessage:"New session"' 'defaultMessage:"新建会话"'
    Add-Patch 'defaultMessage:"Customize"' 'defaultMessage:"自定义"'
    Add-Patch 'defaultMessage:"Recents"' 'defaultMessage:"最近"'
    Add-Patch 'defaultMessage:"More"' 'defaultMessage:"更多"'
    Add-Patch 'defaultMessage:"Theme"' 'defaultMessage:"主题"'
    Add-Patch 'defaultMessage:"Match system"' 'defaultMessage:"跟随系统"'
    Add-Patch 'defaultMessage:"Font"' 'defaultMessage:"字体"'
    Add-Patch 'defaultMessage:"System"' 'defaultMessage:"系统"'
    Add-Patch 'children:"More"' 'children:"更多"'
    Add-Patch 'children:["More"' 'children:["更多"'
    Add-Patch 'title:"More"' 'title:"更多"'

    Add-Patch 'defaultMessage:"Projects"' 'defaultMessage:"项目"'
    Add-Patch 'defaultMessage:"New project"' 'defaultMessage:"新建项目"'
    Add-Patch 'title:"Projects"' 'title:"项目"'
    Add-Patch 'placeholder:"Search projects"' 'placeholder:"搜索项目"'
    Add-Patch 'const He="New project"' 'const He="新建项目"'
    Add-Patch 'Ge={yours:"Your projects",team:"Team",shared:"Shared with you"}' 'Ge={yours:"你的项目",team:"团队",shared:"与你共享"}'
    Add-Patch 'es={yours:"You don''t have any projects yet.",team:"No team projects yet.",shared:"No projects have been shared with you."}' 'es={yours:"你还没有任何项目。",team:"还没有团队项目。",shared:"还没有与你共享的项目。"}'
    Add-Patch 'as={recent:"Recent",created:"Created",alphabetical:"Alphabetical"}' 'as={recent:"最近",created:"创建时间",alphabetical:"按字母排序"}'
    Add-Patch 'return e.name||"Untitled"' 'return e.name||"未命名"'
    Add-Patch 'return"chatProject"===e.kind?"Chat project":"Space"' 'return"chatProject"===e.kind?"聊天项目":"空间"'

    Add-Patch 'defaultMessage:"Scheduled tasks"' 'defaultMessage:"计划任务"'
    Add-Patch 'title:"Scheduled tasks"' 'title:"计划任务"'
    Add-Patch 'children:"New task"' 'children:"新任务"'
    Add-Patch 'defaultMessage:"New task"' 'defaultMessage:"新任务"'
    Add-Patch 'defaultMessage:"New remote task"' 'defaultMessage:"新建远程任务"'
    Add-Patch 'defaultMessage:"Run tasks on a schedule or whenever you need them. Type <code>/schedule</code> in any existing session to set one up."' 'defaultMessage:"按计划运行任务，或在需要时运行。在任何现有会话中输入 <code>/schedule</code> 即可设置。"'
    Add-Patch 'defaultMessage:"Run tasks on a schedule or whenever you need them. Type <code>/schedule</code> in any existing task to set one up."' 'defaultMessage:"按计划运行任务，或在需要时运行。在任何现有任务中输入 <code>/schedule</code> 即可设置。"'
    Add-Patch 'children:"Run tasks on a schedule or whenever you need them. Type /schedule in any existing task to set one up."' 'children:"按计划运行任务，或在需要时运行。在任何现有任务中输入 /schedule 即可设置。"'
    Add-Patch 'defaultMessage:"Scheduled tasks only run while your computer is awake."' 'defaultMessage:"计划任务仅在电脑保持唤醒时运行。"'
    Add-Patch 'message:"Scheduled tasks only run while your computer is awake."' 'message:"计划任务仅在电脑保持唤醒时运行。"'
    Add-Patch 'defaultMessage:"No scheduled tasks yet."' 'defaultMessage:"还没有计划任务。"'
    Add-Patch 'children:[m.jsx(Bqe,{size:"medium"}),"No scheduled tasks yet."]' 'children:[m.jsx(Bqe,{size:"medium"}),"还没有计划任务。"]'
    Add-Patch 'children:"No scheduled tasks match your search."' 'children:"没有匹配的计划任务。"'
    Add-Patch 'placeholder:"Filter scheduled tasks"' 'placeholder:"筛选计划任务"'
    Add-Patch 'defaultMessage:"Other scheduled tasks were already running."' 'defaultMessage:"其他计划任务已经在运行。"'
    Add-Patch 'defaultMessage:"Scheduled tasks use a randomized delay of several minutes for server performance."' 'defaultMessage:"为了服务器性能，计划任务会随机延迟几分钟运行。"'
    Add-Patch '"aria-label":"Sort by"' '"aria-label":"排序方式"'
    Add-Patch 'n=Pi(t.name)' 'n=({"consolidate-memory":"整理记忆","context":"上下文","schedule":"定时任务","setup-cowork":"设置协作"}[t.name]??Pi(t.name))'
    Add-Patch 'skillId:e.name,label:e.name,skillDescription:e.description??""' 'skillId:e.name,label:({"consolidate-memory":"整理记忆","context":"上下文","schedule":"定时任务","setup-cowork":"设置协作"}[e.name]??e.name),skillDescription:({"consolidate-memory":"对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。","context":"查看和管理当前会话上下文。","schedule":"创建一个可按需运行或按固定间隔自动运行的定时任务。","setup-cowork":"引导完成协作模式设置：安装匹配插件、试用技能、连接工具。"}[e.name]??e.description??"")'
    Add-Patch 'label:e.name,icon:PPe,skillId:e.name,skillDescription:e.description??""' 'label:({"consolidate-memory":"整理记忆","context":"上下文","schedule":"定时任务","setup-cowork":"设置协作"}[e.name]??e.name),icon:PPe,skillId:e.name,skillDescription:({"consolidate-memory":"对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。","context":"查看和管理当前会话上下文。","schedule":"创建一个可按需运行或按固定间隔自动运行的定时任务。","setup-cowork":"引导完成协作模式设置：安装匹配插件、试用技能、连接工具。"}[e.name]??e.description??"")'

    return $patches
}

function Patch-JavaScriptAssets {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    $assetRoot = Join-Path $InstallRoot 'resources\ion-dist\assets\v1'
    if (-not (Test-Path -LiteralPath $assetRoot -PathType Container)) {
        throw "Asset directory not found: $assetRoot"
    }

    $patches = New-Patches
    $jsFiles = Get-ChildItem -LiteralPath $assetRoot -Filter '*.js' -File
    foreach ($file in $jsFiles) {
        $content = [IO.File]::ReadAllText($file.FullName)
        $original = $content
        foreach ($patch in $patches) {
            if ($content.Contains($patch.Find)) {
                $content = $content.Replace($patch.Find, $patch.Replace)
            }
        }

        if ($content -ne $original) {
            Write-Step "Patching JS asset: $($file.Name)"
            Grant-WriteAccess -Path $file.FullName
            [IO.File]::WriteAllText($file.FullName, $content, $Utf8NoBom)
            $ChangedFiles.Add($file.FullName)
        }
    }
}

function Set-ClaudeLocale {
    $roots = Get-ClaudeProfileRoots
    foreach ($root in $roots) {
        $configPath = Join-Path $root 'config.json'
        if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
            continue
        }

        Write-Step "Setting locale=zh-CN in $configPath"
        $text = [IO.File]::ReadAllText($configPath)
        $config = $text | ConvertFrom-Json
        if ($null -eq $config) {
            $config = [pscustomobject]@{}
        }
        if ($config.PSObject.Properties.Name -contains 'locale') {
            $config.locale = 'zh-CN'
        }
        else {
            Add-Member -InputObject $config -NotePropertyName 'locale' -NotePropertyValue 'zh-CN'
        }
        [IO.File]::WriteAllText($configPath, ($config | ConvertTo-Json -Depth 100), $Utf8NoBom)
        $ChangedFiles.Add($configPath)
    }
}

function Patch-SkillsManifests {
    $roots = Get-ClaudeProfileRoots
    foreach ($root in $roots) {
        $skillsRoot = Join-Path $root 'local-agent-mode-sessions\skills-plugin'
        if (-not (Test-Path -LiteralPath $skillsRoot -PathType Container)) {
            continue
        }

        $manifests = Get-ChildItem -LiteralPath $skillsRoot -Recurse -File -Filter 'manifest.json' -ErrorAction SilentlyContinue
        foreach ($manifest in $manifests) {
            try {
                $text = [IO.File]::ReadAllText($manifest.FullName)
                $obj = $text | ConvertFrom-Json
                if (-not $obj.skills) {
                    continue
                }

                $changed = $false
                foreach ($skill in $obj.skills) {
                    switch ($skill.skillId) {
                        'schedule' {
                            if ($skill.name -ne '定时任务' -or $skill.description -ne '创建一个可按需运行或按固定间隔自动运行的定时任务。') {
                                $skill.name = '定时任务'
                                $skill.description = '创建一个可按需运行或按固定间隔自动运行的定时任务。'
                                $changed = $true
                            }
                        }
                        'setup-cowork' {
                            if ($skill.name -ne '设置协作' -or $skill.description -ne '引导完成协作模式设置：安装匹配插件、试用技能、连接工具。') {
                                $skill.name = '设置协作'
                                $skill.description = '引导完成协作模式设置：安装匹配插件、试用技能、连接工具。'
                                $changed = $true
                            }
                        }
                        'consolidate-memory' {
                            if ($skill.name -ne '整理记忆' -or $skill.description -ne '对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。') {
                                $skill.name = '整理记忆'
                                $skill.description = '对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。'
                                $changed = $true
                            }
                        }
                    }
                }

                if ($changed) {
                    Write-Step "Patching skills manifest: $($manifest.FullName)"
                    [IO.File]::WriteAllText($manifest.FullName, ($obj | ConvertTo-Json -Depth 20), $Utf8NoBom)
                    $ChangedFiles.Add($manifest.FullName)
                }
            }
            catch {
                Write-Warning "Skipping manifest $($manifest.FullName): $($_.Exception.Message)"
            }
        }
    }
}

function Patch-SkillMarkdowns {
    $roots = Get-ClaudeProfileRoots
    foreach ($root in $roots) {
        $skillsRoot = Join-Path $root 'local-agent-mode-sessions\skills-plugin'
        if (-not (Test-Path -LiteralPath $skillsRoot -PathType Container)) {
            continue
        }

        $skillFiles = Get-ChildItem -LiteralPath $skillsRoot -Recurse -File -Filter 'SKILL.md' -ErrorAction SilentlyContinue
        foreach ($skillFile in $skillFiles) {
            try {
                $content = [IO.File]::ReadAllText($skillFile.FullName)
                $updated = $content.
                    Replace('description: "Create a scheduled task that can be run on demand or automatically on an interval."', 'description: "创建一个可按需运行或按固定间隔自动运行的定时任务。"').
                    Replace('description: "Guided Cowork setup — install a matching plugin, try a skill, connect tools."', 'description: "引导完成协作模式设置：安装匹配插件、试用技能、连接工具。"').
                    Replace('description: "Reflective pass over your memory files — merge duplicates, fix stale facts, prune the index."', 'description: "对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。"')

                if ($updated -ne $content) {
                    Write-Step "Patching skill markdown: $($skillFile.FullName)"
                    [IO.File]::WriteAllText($skillFile.FullName, $updated, $Utf8NoBom)
                    $ChangedFiles.Add($skillFile.FullName)
                }
            }
            catch {
                Write-Warning "Skipping skill markdown $($skillFile.FullName): $($_.Exception.Message)"
            }
        }
    }
}

function Launch-Claude {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    $exe = Join-Path $InstallRoot 'Claude.exe'
    if (Test-Path -LiteralPath $exe -PathType Leaf) {
        Write-Step 'Launching Claude with --lang=zh-CN'
        Start-Process -FilePath $exe -ArgumentList '--lang=zh-CN'
    }
}

Assert-Admin
$installRoot = Find-ClaudeAppRoot
Write-Step "Claude app root: $installRoot"

Stop-Claude
Clear-CodeCaches
Copy-LanguageFiles -InstallRoot $installRoot
Patch-JavaScriptAssets -InstallRoot $installRoot
Patch-SkillMarkdowns
Patch-SkillsManifests
Set-ClaudeLocale
Launch-Claude -InstallRoot $installRoot

Write-Step "Install complete. Changed files: $($ChangedFiles.Count)"
