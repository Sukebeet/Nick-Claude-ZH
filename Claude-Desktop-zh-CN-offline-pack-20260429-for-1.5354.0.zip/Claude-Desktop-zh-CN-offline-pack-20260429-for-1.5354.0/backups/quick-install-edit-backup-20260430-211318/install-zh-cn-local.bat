@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "INSTALL_PS1=%SCRIPT_DIR%scripts\install-claude-zh-cn-local-20260429.ps1"

if not exist "%INSTALL_PS1%" (
  echo [ERROR] Missing installer script:
  echo %INSTALL_PS1%
  pause
  exit /b 1
)

echo Launching localized installer with administrator privilege...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'powershell.exe' -Verb RunAs -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%INSTALL_PS1%';"

echo.
echo Installer window has finished.
echo If Claude did not open automatically, start Claude Desktop once manually.
pause
