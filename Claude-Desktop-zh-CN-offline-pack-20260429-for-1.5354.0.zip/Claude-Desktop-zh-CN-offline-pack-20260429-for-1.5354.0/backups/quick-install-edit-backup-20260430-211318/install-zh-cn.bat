@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "INSTALL_PS1=%SCRIPT_DIR%scripts\install-claude-zh-cn.ps1"

if not exist "%INSTALL_PS1%" (
  echo [ERROR] Missing installer script:
  echo %INSTALL_PS1%
  pause
  exit /b 1
)

set "PWSH="
if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PWSH=%ProgramFiles%\PowerShell\7\pwsh.exe"
if not defined PWSH if exist "%LocalAppData%\Microsoft\WindowsApps\pwsh.exe" set "PWSH=%LocalAppData%\Microsoft\WindowsApps\pwsh.exe"

if not defined PWSH (
  echo [ERROR] PowerShell 7 ^(pwsh.exe^) was not found.
  echo Install PowerShell 7 first, then run:
  echo pwsh -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_PS1%"
  pause
  exit /b 1
)

echo Launching installer with administrator privilege...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%PWSH%' -Verb RunAs -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%INSTALL_PS1%';"

echo.
echo Installer window has finished.
echo If Claude did not open automatically, start Claude Desktop once manually.
pause
