﻿param(
    [Parameter(Mandatory = $true)][string]$BackupRoot,
    [string]$ClaudeAppRoot = '',
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

function Write-Step {
    param([Parameter(Mandatory = $true)][string]$Message)
    Write-Host "[Claude zh-CN rollback] $Message" -ForegroundColor Cyan
}

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Administrator privilege is required. Re-run this script from an elevated PowerShell 7 window."
    }
}

function Find-ClaudeAppRoot {
    param([string]$ExplicitRoot)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRoot)) {
        if (-not (Test-Path -LiteralPath $ExplicitRoot -PathType Container)) {
            throw "ClaudeAppRoot does not exist: $ExplicitRoot"
        }
        return (Resolve-Path -LiteralPath $ExplicitRoot).Path
    }

    $windowsApps = Join-Path $env:ProgramFiles 'WindowsApps'
    $candidates = Get-ChildItem -LiteralPath $windowsApps -Directory -Filter 'Claude_*__pzs8sxrjxfjjc' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $app = Join-Path $_.FullName 'app'
            $exe = Join-Path $app 'Claude.exe'
            if (Test-Path -LiteralPath $exe -PathType Leaf) {
                [pscustomobject]@{
                    AppRoot = $app
                    LastWriteTime = $_.LastWriteTime
                }
            }
        }

    if (-not $candidates -or $candidates.Count -eq 0) {
        throw "Could not find Claude Desktop. Pass -ClaudeAppRoot manually."
    }

    return ($candidates | Sort-Object LastWriteTime -Descending | Select-Object -First 1).AppRoot
}

function Grant-WriteAccess {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $currentGrant = ('*' + $currentSid + ':(F)')

    & takeown.exe /F $Path /A | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "takeown failed for $Path"
    }
    & icacls.exe $Path /grant:r '*S-1-5-32-544:(F)' | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "icacls administrators grant failed for $Path"
    }
    & icacls.exe $Path /grant:r $currentGrant | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "icacls current user grant failed for $Path"
    }
}

function Resolve-TargetPath {
    param(
        [Parameter(Mandatory = $true)][string]$BackupFile,
        [Parameter(Mandatory = $true)][string]$BackupRootPath,
        [Parameter(Mandatory = $true)][string]$InstallRoot
    )

    $relative = $BackupFile.Substring($BackupRootPath.Length).TrimStart('\')
    if ($relative.StartsWith('external\', [StringComparison]::OrdinalIgnoreCase)) {
        $externalRelative = $relative.Substring('external\'.Length)
        if ($externalRelative.Length -ge 3 -and $externalRelative[1] -eq '\') {
            return ($externalRelative.Substring(0, 1) + ':\' + $externalRelative.Substring(2))
        }
        return $externalRelative
    }

    return Join-Path $InstallRoot $relative
}

Assert-Admin
if (-not (Test-Path -LiteralPath $BackupRoot -PathType Container)) {
    throw "BackupRoot does not exist: $BackupRoot"
}

$installRoot = Find-ClaudeAppRoot -ExplicitRoot $ClaudeAppRoot
Write-Step "Claude app root: $installRoot"
Write-Step "Backup root: $BackupRoot"

Get-Process | Where-Object { $_.ProcessName -like 'Claude*' } | Stop-Process -Force

$backupFiles = Get-ChildItem -LiteralPath $BackupRoot -Recurse -File
foreach ($file in $backupFiles) {
    $target = Resolve-TargetPath -BackupFile $file.FullName -BackupRootPath (Resolve-Path -LiteralPath $BackupRoot).Path -InstallRoot $installRoot
    $targetDir = Split-Path -Parent $target
    if (-not (Test-Path -LiteralPath $targetDir -PathType Container)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    Grant-WriteAccess -Path $targetDir
    if (Test-Path -LiteralPath $target) {
        Grant-WriteAccess -Path $target
    }
    Write-Step "Restoring $($file.FullName) -> $target"
    Copy-Item -LiteralPath $file.FullName -Destination $target -Force
}

if (-not $NoLaunch) {
    $exe = Join-Path $installRoot 'Claude.exe'
    if (Test-Path -LiteralPath $exe -PathType Leaf) {
        Start-Process -FilePath $exe
    }
}

Write-Step "Rollback complete."
