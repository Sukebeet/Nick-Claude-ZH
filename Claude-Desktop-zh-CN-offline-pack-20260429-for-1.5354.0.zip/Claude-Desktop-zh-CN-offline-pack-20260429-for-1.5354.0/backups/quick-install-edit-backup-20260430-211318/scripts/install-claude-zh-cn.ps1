﻿param(
    [string]$ClaudeAppRoot = '',
    [string]$BackupRoot = '',
    [switch]$DryRun,
    [switch]$SkipHardcodedPatch,
    [switch]$SandboxMode,
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$PackageRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$PayloadRoot = Join-Path $PackageRoot 'payload\merged'
$RunStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $BackupRoot = Join-Path $PackageRoot "backups\claude-zh-cn-backup-$RunStamp"
}
$LogPath = Join-Path $PackageRoot "logs\install-$RunStamp.log"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:BackedUp = @{}
$script:ChangedFiles = New-Object System.Collections.Generic.List[string]

function Write-Step {
    param([Parameter(Mandatory = $true)][string]$Message)
    Write-Host "[Claude zh-CN installer] $Message" -ForegroundColor Cyan
}

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Administrator privilege is required. Re-run this script from an elevated PowerShell 7 window."
    }
}

function Find-ClaudeAppRoot {
    param([string]$ExplicitRoot)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitRoot)) {
        if (-not (Test-Path -LiteralPath $ExplicitRoot -PathType Container)) {
            throw "ClaudeAppRoot does not exist: $ExplicitRoot"
        }
        return (Resolve-Path -LiteralPath $ExplicitRoot).Path
    }

    $windowsApps = Join-Path $env:ProgramFiles 'WindowsApps'
    $candidates = Get-ChildItem -LiteralPath $windowsApps -Directory -Filter 'Claude_*__pzs8sxrjxfjjc' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $app = Join-Path $_.FullName 'app'
            $exe = Join-Path $app 'Claude.exe'
            if (Test-Path -LiteralPath $exe -PathType Leaf) {
                [pscustomobject]@{
                    AppRoot = $app
                    Name = $_.Name
                    LastWriteTime = $_.LastWriteTime
                }
            }
        }

    if (-not $candidates -or $candidates.Count -eq 0) {
        throw "Could not find Claude Desktop under $windowsApps. Pass -ClaudeAppRoot manually."
    }

    return ($candidates | Sort-Object LastWriteTime -Descending | Select-Object -First 1).AppRoot
}

function Grant-WriteAccess {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    if ($SandboxMode) {
        return
    }

    if ($DryRun) {
        Write-Step "DryRun: would grant write access to $Path"
        return
    }

    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $currentGrant = ('*' + $currentSid + ':(F)')

    & takeown.exe /F $Path /A | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "takeown failed for $Path"
    }

    & icacls.exe $Path /grant:r '*S-1-5-32-544:(F)' | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "icacls administrators grant failed for $Path"
    }

    & icacls.exe $Path /grant:r $currentGrant | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "icacls current user grant failed for $Path"
    }
}

function Backup-File {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$InstallRoot
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return
    }
    if ($script:BackedUp.ContainsKey($Path)) {
        return
    }

    if ($Path.StartsWith($InstallRoot, [StringComparison]::OrdinalIgnoreCase)) {
        $relative = $Path.Substring($InstallRoot.Length).TrimStart('\')
        $destination = Join-Path $BackupRoot $relative
    }
    else {
        $safeRelative = ($Path -replace ':', '').TrimStart('\')
        $destination = Join-Path (Join-Path $BackupRoot 'external') $safeRelative
    }

    if ($DryRun) {
        Write-Step "DryRun: would back up $Path -> $destination"
        $script:BackedUp[$Path] = $true
        return
    }

    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $Path -Destination $destination -Force
    $script:BackedUp[$Path] = $true
}

function Stop-Claude {
    $processes = Get-Process | Where-Object { $_.ProcessName -like 'Claude*' }
    foreach ($process in $processes) {
        Write-Step "Stopping $($process.ProcessName) ($($process.Id))"
        if (-not $DryRun) {
            Stop-Process -Id $process.Id -Force
        }
    }
}

function Reset-CodeCache {
    if (-not $env:APPDATA -or -not (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
        return
    }

    $profileDirs = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue
    foreach ($profileDir in $profileDirs) {
        $cacheDir = Join-Path $profileDir.FullName 'Code Cache'
        if (-not (Test-Path -LiteralPath $cacheDir -PathType Container)) {
            continue
        }

        $backupPath = $cacheDir + ".zh-cn-backup-$RunStamp"
        Write-Step "Resetting stale code cache: $cacheDir"
        if (-not $DryRun) {
            if (Test-Path -LiteralPath $backupPath) {
                Remove-Item -LiteralPath $backupPath -Recurse -Force
            }
            Move-Item -LiteralPath $cacheDir -Destination $backupPath
        }
    }
}

function Copy-LanguageFiles {
    param(
        [Parameter(Mandatory = $true)][string]$InstallRoot
    )

    $resources = Join-Path $InstallRoot 'resources'
    $copyMap = @(
        [pscustomobject]@{
            Source = Join-Path $PayloadRoot 'desktop-shell.zh-CN.json'
            Destination = Join-Path $resources 'zh-CN.json'
        },
        [pscustomobject]@{
            Source = Join-Path $PayloadRoot 'ion-dist.zh-CN.json'
            Destination = Join-Path $resources 'ion-dist\i18n\zh-CN.json'
        },
        [pscustomobject]@{
            Source = Join-Path $PayloadRoot 'statsig.zh-CN.json'
            Destination = Join-Path $resources 'ion-dist\i18n\statsig\zh-CN.json'
        }
    )

    foreach ($item in $copyMap) {
        if (-not (Test-Path -LiteralPath $item.Source -PathType Leaf)) {
            throw "Missing payload file: $($item.Source)"
        }

        Backup-File -Path $item.Destination -InstallRoot $InstallRoot
        $destinationDir = Split-Path -Parent $item.Destination
        Grant-WriteAccess -Path $destinationDir
        if (Test-Path -LiteralPath $item.Destination) {
            Grant-WriteAccess -Path $item.Destination
        }

        Write-Step "Copying $($item.Source) -> $($item.Destination)"
        if (-not $DryRun) {
            Copy-Item -LiteralPath $item.Source -Destination $item.Destination -Force
        }
        $script:ChangedFiles.Add($item.Destination)
    }
}

function Set-ClaudeLocale {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    $configFiles = @()
    if ($env:APPDATA -and (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
        $configFiles = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue |
            ForEach-Object { Join-Path $_.FullName 'config.json' } |
            Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }
    }

    foreach ($configPath in $configFiles) {
        Backup-File -Path $configPath -InstallRoot $InstallRoot
        Write-Step "Setting locale=zh-CN in $configPath"
        if ($DryRun) {
            continue
        }

        $text = [IO.File]::ReadAllText($configPath)
        $config = $text | ConvertFrom-Json
        if ($null -eq $config) {
            $config = [pscustomobject]@{}
        }
        if ($config.PSObject.Properties.Name -contains 'locale') {
            $config.locale = 'zh-CN'
        }
        else {
            Add-Member -InputObject $config -NotePropertyName 'locale' -NotePropertyValue 'zh-CN'
        }
        [IO.File]::WriteAllText($configPath, ($config | ConvertTo-Json -Depth 100), $Utf8NoBom)
        $script:ChangedFiles.Add($configPath)
    }
}

function Patch-SkillsManifests {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    if (-not $env:APPDATA -or -not (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
        return
    }

    $manifests = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $skillsRoot = Join-Path $_.FullName 'local-agent-mode-sessions\skills-plugin'
            if (Test-Path -LiteralPath $skillsRoot -PathType Container) {
                Get-ChildItem -LiteralPath $skillsRoot -Recurse -File -Filter 'manifest.json' -ErrorAction SilentlyContinue
            }
        }

    foreach ($manifest in $manifests) {
        try {
            $text = [IO.File]::ReadAllText($manifest.FullName)
            $obj = $text | ConvertFrom-Json
            if (-not $obj.skills) {
                continue
            }

            $changed = $false
            foreach ($skill in $obj.skills) {
                switch ($skill.skillId) {
                    'schedule' {
                        if ($skill.name -ne '定时任务' -or $skill.description -ne '创建一个可按需运行或按固定间隔自动运行的定时任务。') {
                            $skill.name = '定时任务'
                            $skill.description = '创建一个可按需运行或按固定间隔自动运行的定时任务。'
                            $changed = $true
                        }
                    }
                    'setup-cowork' {
                        if ($skill.name -ne '设置协作' -or $skill.description -ne '引导完成协作模式设置：安装匹配插件、试用技能、连接工具。') {
                            $skill.name = '设置协作'
                            $skill.description = '引导完成协作模式设置：安装匹配插件、试用技能、连接工具。'
                            $changed = $true
                        }
                    }
                    'consolidate-memory' {
                        if ($skill.name -ne '整理记忆' -or $skill.description -ne '对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。') {
                            $skill.name = '整理记忆'
                            $skill.description = '对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。'
                            $changed = $true
                        }
                    }
                }
            }

            if ($changed) {
                Write-Step "Patching skills manifest: $($manifest.FullName)"
                Backup-File -Path $manifest.FullName -InstallRoot $InstallRoot
                if (-not $DryRun) {
                    [IO.File]::WriteAllText($manifest.FullName, ($obj | ConvertTo-Json -Depth 20), $Utf8NoBom)
                }
                $script:ChangedFiles.Add($manifest.FullName)
            }
        }
        catch {
            Write-Warning "Skipping manifest $($manifest.FullName): $($_.Exception.Message)"
        }
    }
}

function Patch-SkillMarkdowns {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    if (-not $env:APPDATA -or -not (Test-Path -LiteralPath $env:APPDATA -PathType Container)) {
        return
    }

    $skillFiles = Get-ChildItem -LiteralPath $env:APPDATA -Directory -Filter 'Claude*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $skillsRoot = Join-Path $_.FullName 'local-agent-mode-sessions\skills-plugin'
            if (Test-Path -LiteralPath $skillsRoot -PathType Container) {
                Get-ChildItem -LiteralPath $skillsRoot -Recurse -File -Filter 'SKILL.md' -ErrorAction SilentlyContinue
            }
        }

    foreach ($skillFile in $skillFiles) {
        try {
            $content = [IO.File]::ReadAllText($skillFile.FullName)
            $updated = $content.
                Replace('description: "Create a scheduled task that can be run on demand or automatically on an interval."', 'description: "创建一个可按需运行或按固定间隔自动运行的定时任务。"').
                Replace('description: "Guided Cowork setup — install a matching plugin, try a skill, connect tools."', 'description: "引导完成协作模式设置：安装匹配插件、试用技能、连接工具。"').
                Replace('description: "Reflective pass over your memory files — merge duplicates, fix stale facts, prune the index."', 'description: "对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。"')

            if ($updated -ne $content) {
                Write-Step "Patching skill markdown: $($skillFile.FullName)"
                Backup-File -Path $skillFile.FullName -InstallRoot $InstallRoot
                if (-not $DryRun) {
                    [IO.File]::WriteAllText($skillFile.FullName, $updated, $Utf8NoBom)
                }
                $script:ChangedFiles.Add($skillFile.FullName)
            }
        }
        catch {
            Write-Warning "Skipping skill markdown $($skillFile.FullName): $($_.Exception.Message)"
        }
    }
}

function New-Patches {
    $patches = New-Object System.Collections.Generic.List[object]
    function Add-Patch([string]$Find, [string]$Replace) {
        $patches.Add([pscustomobject]@{ Find = $Find; Replace = $Replace })
    }

    Add-Patch '$z=["en-US","de-DE","fr-FR","ko-KR","ja-JP","es-419","es-ES","it-IT","hi-IN","pt-BR","id-ID"]' '$z=["en-US","zh-CN","de-DE","fr-FR","ko-KR","ja-JP","es-419","es-ES","it-IT","hi-IN","pt-BR","id-ID"]'

    Add-Patch 'label:"Chat"' 'label:"聊天"'
    Add-Patch 'label:"Cowork"' 'label:"协作"'
    Add-Patch 'label:"Code"' 'label:"代码"'
    Add-Patch 'label:"Customize"' 'label:"自定义"'
    Add-Patch 'name:"Customize"' 'name:"自定义"'
    Add-Patch 'label:"Projects"' 'label:"项目"'
    Add-Patch 'label:"Scheduled"' 'label:"计划任务"'
    Add-Patch 'label:"Live artifacts"' 'label:"实时制品"'
    Add-Patch 'label:"Dispatch"' 'label:"调度"'
    Add-Patch 'ariaLabel:"Code"' 'ariaLabel:"代码"'

    Add-Patch 'const hi="Recents"' 'const hi="最近"'
    Add-Patch 'chat:"New chat"' 'chat:"新聊天"'
    Add-Patch 'cowork:"New task"' 'cowork:"新任务"'
    Add-Patch 'code:"New session"' 'code:"新建会话"'
    Add-Patch 'operon:"New session"' 'operon:"新建会话"'
    Add-Patch 'children:["View all"' 'children:["查看全部"'
    Add-Patch 'children:"Pinned"' 'children:"已固定"'
    Add-Patch '"Let go"' '"松开"'
    Add-Patch '"Drop here"' '"拖到这里"'
    Add-Patch '"Drag to pin"' '"拖动固定"'
    Add-Patch 'mi="Untitled"' 'mi="未命名"'
 Add-Patch '"Recents"' '"最近"'
 Add-Patch '"Untitled"' '"未命名"'
 Add-Patch '||"Untitled"' '||"未命名"'
 Add-Patch 'defaultMessage:"Untitled"' 'defaultMessage:"未命名"'
 Add-Patch ':"Recent"' ':"最近"'
 Add-Patch 'recent:"Recent"' 'recent:"最近"'
 Add-Patch 'defaultMessage:"Recent"' 'defaultMessage:"最近"'
 Add-Patch 'defaultMessage:"Recents"' 'defaultMessage:"最近"'

    Add-Patch 'children:e.jsx(s,{defaultMessage:"Recents"' 'children:e.jsx(s,{defaultMessage:"最近"'
 Add-Patch 'mdTitle:e.jsx(s,{defaultMessage:"Recents"' 'mdTitle:e.jsx(s,{defaultMessage:"最近"'
 Add-Patch 'title:"Recents"' 'title:"最近"'
 Add-Patch 'defaultMessage:"Code"' 'defaultMessage:"代码"'
    Add-Patch 'defaultMessage:"New session"' 'defaultMessage:"新建会话"'
    Add-Patch 'defaultMessage:"Customize"' 'defaultMessage:"自定义"'
    Add-Patch 'children:[s.jsx(mr,{className:"w-3.5 h-3.5"}),"Sign out"]' 'children:[s.jsx(mr,{className:"w-3.5 h-3.5"}),"退出登录"]'
    Add-Patch 'defaultMessage:"Recents"' 'defaultMessage:"最近"'
    Add-Patch 'defaultMessage:"More"' 'defaultMessage:"更多"'
    Add-Patch 'defaultMessage:"Theme"' 'defaultMessage:"主题"'
    Add-Patch 'defaultMessage:"Match system"' 'defaultMessage:"跟随系统"'
    Add-Patch 'defaultMessage:"Font"' 'defaultMessage:"字体"'
    Add-Patch 'defaultMessage:"System"' 'defaultMessage:"系统"'
    Add-Patch 'children:"More"' 'children:"更多"'
    Add-Patch 'children:["More"' 'children:["更多"'
    Add-Patch 'title:"More"' 'title:"更多"'

    Add-Patch 'defaultMessage:"Projects"' 'defaultMessage:"项目"'
    Add-Patch 'defaultMessage:"New project"' 'defaultMessage:"新建项目"'
    Add-Patch 'title:"Projects"' 'title:"项目"'
    Add-Patch 'placeholder:"Search projects"' 'placeholder:"搜索项目"'
    Add-Patch 'const He="New project"' 'const He="新建项目"'
    Add-Patch 'const Je="New project"' 'const Je="新建项目"'
    Add-Patch 'Ge={yours:"Your projects",team:"Team",shared:"Shared with you"}' 'Ge={yours:"你的项目",team:"团队",shared:"与你共享"}'
    Add-Patch 'es={yours:"You don''t have any projects yet.",team:"No team projects yet.",shared:"No projects have been shared with you."}' 'es={yours:"你还没有任何项目。",team:"还没有团队项目。",shared:"还没有与你共享的项目。"}'
    Add-Patch 'as={recent:"Recent",created:"Created",alphabetical:"Alphabetical"}' 'as={recent:"最近",created:"创建时间",alphabetical:"按字母排序"}'
    Add-Patch 'return e.name||"Untitled"' 'return e.name||"未命名"'
    Add-Patch 'return"chatProject"===e.kind?"Chat project":"Space"' 'return"chatProject"===e.kind?"聊天项目":"空间"'

    Add-Patch 'defaultMessage:"Scheduled tasks"' 'defaultMessage:"计划任务"'
    Add-Patch 'title:"Scheduled tasks"' 'title:"计划任务"'
    Add-Patch 'children:"New task"' 'children:"新任务"'
    Add-Patch 'defaultMessage:"New task"' 'defaultMessage:"新任务"'
    Add-Patch 'defaultMessage:"New remote task"' 'defaultMessage:"新建远程任务"'
    Add-Patch 'defaultMessage:"Run tasks on a schedule or whenever you need them. Type <code>/schedule</code> in any existing session to set one up."' 'defaultMessage:"按计划运行任务，或在需要时运行。在任何现有会话中输入 <code>/schedule</code> 即可设置。"'
    Add-Patch 'defaultMessage:"Run tasks on a schedule or whenever you need them. Type <code>/schedule</code> in any existing task to set one up."' 'defaultMessage:"按计划运行任务，或在需要时运行。在任何现有任务中输入 <code>/schedule</code> 即可设置。"'
    Add-Patch 'children:"Run tasks on a schedule or whenever you need them. Type /schedule in any existing task to set one up."' 'children:"按计划运行任务，或在需要时运行。在任何现有任务中输入 /schedule 即可设置。"'
    Add-Patch 'defaultMessage:"Scheduled tasks only run while your computer is awake."' 'defaultMessage:"计划任务仅在电脑保持唤醒时运行。"'
    Add-Patch 'message:"Scheduled tasks only run while your computer is awake."' 'message:"计划任务仅在电脑保持唤醒时运行。"'
    Add-Patch 'defaultMessage:"No scheduled tasks yet."' 'defaultMessage:"还没有计划任务。"'
    Add-Patch 'children:[m.jsx(Bqe,{size:"medium"}),"No scheduled tasks yet."]' 'children:[m.jsx(Bqe,{size:"medium"}),"还没有计划任务。"]'
    Add-Patch 'children:"No scheduled tasks match your search."' 'children:"没有匹配的计划任务。"'
    Add-Patch 'placeholder:"Filter scheduled tasks"' 'placeholder:"筛选计划任务"'
    Add-Patch 'defaultMessage:"Other scheduled tasks were already running."' 'defaultMessage:"其他计划任务已经在运行。"'
    Add-Patch 'defaultMessage:"Scheduled tasks use a randomized delay of several minutes for server performance."' 'defaultMessage:"为了服务器性能，计划任务会随机延迟几分钟运行。"'
    Add-Patch '"aria-label":"Sort by"' '"aria-label":"排序方式"'
    Add-Patch 'n=Pi(t.name)' 'n=({"consolidate-memory":"整理记忆","context":"上下文","schedule":"定时任务","setup-cowork":"设置协作"}[t.name]??Pi(t.name))'
    Add-Patch 'skillId:e.name,label:e.name,skillDescription:e.description??""' 'skillId:e.name,label:({"consolidate-memory":"整理记忆","context":"上下文","schedule":"定时任务","setup-cowork":"设置协作"}[e.name]??e.name),skillDescription:({"consolidate-memory":"对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。","context":"查看和管理当前会话上下文。","schedule":"创建一个可按需运行或按固定间隔自动运行的定时任务。","setup-cowork":"引导完成协作模式设置：安装匹配插件、试用技能、连接工具。"}[e.name]??e.description??"")'
    Add-Patch 'label:e.name,icon:PPe,skillId:e.name,skillDescription:e.description??""' 'label:({"consolidate-memory":"整理记忆","context":"上下文","schedule":"定时任务","setup-cowork":"设置协作"}[e.name]??e.name),icon:PPe,skillId:e.name,skillDescription:({"consolidate-memory":"对记忆文件做一次整理：合并重复项、修正过期事实、清理索引。","context":"查看和管理当前会话上下文。","schedule":"创建一个可按需运行或按固定间隔自动运行的定时任务。","setup-cowork":"引导完成协作模式设置：安装匹配插件、试用技能、连接工具。"}[e.name]??e.description??"")'

    return $patches
}

function Patch-JavaScriptAssets {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    if ($SkipHardcodedPatch) {
        Write-Step "Skipping hardcoded JS patches by request."
        return
    }

    $assetRoot = Join-Path $InstallRoot 'resources\ion-dist\assets\v1'
    if (-not (Test-Path -LiteralPath $assetRoot -PathType Container)) {
        throw "Asset directory not found: $assetRoot"
    }

    $patches = New-Patches
    $jsFiles = Get-ChildItem -LiteralPath $assetRoot -Filter '*.js' -File
    foreach ($file in $jsFiles) {
        $content = [IO.File]::ReadAllText($file.FullName)
        $original = $content
        foreach ($patch in $patches) {
            if ($content.Contains($patch.Find)) {
                $content = $content.Replace($patch.Find, $patch.Replace)
            }
        }

        if ($content -ne $original) {
            Write-Step "Patching JS asset: $($file.Name)"
            Backup-File -Path $file.FullName -InstallRoot $InstallRoot
            Grant-WriteAccess -Path $file.FullName
            if (-not $DryRun) {
                [IO.File]::WriteAllText($file.FullName, $content, $Utf8NoBom)
            }
            $script:ChangedFiles.Add($file.FullName)
        }
    }
}

function Launch-Claude {
    param([Parameter(Mandatory = $true)][string]$InstallRoot)

    if ($NoLaunch) {
        return
    }

    $exe = Join-Path $InstallRoot 'Claude.exe'
    if (Test-Path -LiteralPath $exe -PathType Leaf) {
        Write-Step "Launching Claude with --lang=zh-CN"
        if (-not $DryRun) {
            Start-Process -FilePath $exe -ArgumentList '--lang=zh-CN'
        }
    }
}

try {
    New-Item -ItemType Directory -Path (Split-Path -Parent $LogPath) -Force | Out-Null
    try {
        Start-Transcript -Path $LogPath -Force | Out-Null
    }
    catch {
        Write-Warning "Unable to start transcript: $($_.Exception.Message)"
    }

    if ($SandboxMode) {
        $NoLaunch = $true
        Write-Step "SandboxMode: app files will be patched without stopping Claude, changing user config, or launching Claude."
    }
    else {
        Assert-Admin
    }
    $installRoot = Find-ClaudeAppRoot -ExplicitRoot $ClaudeAppRoot
    Write-Step "Claude app root: $installRoot"
    Write-Step "Backup root: $BackupRoot"

    if (-not $SandboxMode) {
        Stop-Claude
        Reset-CodeCache
    }
    Copy-LanguageFiles -InstallRoot $installRoot
    Patch-JavaScriptAssets -InstallRoot $installRoot
    if (-not $SandboxMode) {
        Patch-SkillMarkdowns -InstallRoot $installRoot
        Patch-SkillsManifests -InstallRoot $installRoot
        Set-ClaudeLocale -InstallRoot $installRoot
        Launch-Claude -InstallRoot $installRoot
    }

    Write-Step "Install complete. Changed files: $($script:ChangedFiles.Count)"
    Write-Step "Backup root: $BackupRoot"
    Write-Step "Log: $LogPath"
}
finally {
    try {
        Stop-Transcript | Out-Null
    }
    catch {
    }
}
